<template>
<q-page class="row items-center justify-evenly">
   channel page content coming soon
</q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'

export default defineComponent({
  name: 'ChannelPage'
})
</script>
