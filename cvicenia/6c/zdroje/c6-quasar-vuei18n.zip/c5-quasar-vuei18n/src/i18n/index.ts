import enUS from './en-US'
import sk from './sk-SK'

export default {
  'en-US': enUS,
  'sk-SK': sk
}
