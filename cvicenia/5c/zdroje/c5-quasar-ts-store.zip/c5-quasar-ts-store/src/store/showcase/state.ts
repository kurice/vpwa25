export interface ExampleStateInterface {
  drawerState: boolean;
}

function state (): ExampleStateInterface {
  return {
    drawerState: true
  }
}

export default state
