<template>
  <q-page class="row items-center justify-evenly">
    <q-form @submit.stop="onSubmit">
      <q-card class="q-pa-md">
        <q-card-section>
          <div class="text-h4">Hello TypeScript</div>
        </q-card-section>
        <q-card-section>
          <q-field bottom-slots dense :error="v$.inputText.$error">
            <q-input v-model="inputText"/>
            <template v-slot:hint>
              Count: {{ count }}
            </template>
          </q-field>
        </q-card-section>
        <q-card-actions>
          <q-btn type="submit">Submit</q-btn>
          <q-btn @click="reset()">Reset</q-btn>
        </q-card-actions>
      </q-card>
    </q-form>
  </q-page>
</template>

<script lang="ts">
import { defineComponent } from 'vue'
import useVuelidate from '@vuelidate/core'
import {
  minLength,
  maxLength,
  required
} from '@vuelidate/validators'

interface State {
  inputText: string;
}

export default defineComponent({
  name: 'PageIndex',
  setup () {
    return { v$: useVuelidate({ $autoDirty: true }) }
  },
  data: () : State => {
    return { inputText: '' }
  },
  methods: {
    reset () {
      this.inputText = ''
    },
    async onSubmit () {
      const isFormCorrect = await this.v$.$validate()
      if (!isFormCorrect) {
        this.$q.notify({
          color: 'red-4',
          textColor: 'white',
          icon: 'warning',
          message: this.v$.$errors.map(e => e.$message).join()
        })
      }
    }
  },
  computed: {
    count () {
      return this.inputText.length
    }
  },
  validations () {
    return {
      inputText: {
        required,
        minLength: minLength(2),
        maxLength: maxLength(8)
      }
    }
  }
})
</script>
